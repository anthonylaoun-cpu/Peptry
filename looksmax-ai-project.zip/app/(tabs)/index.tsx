import { View, Text, TouchableOpacity, StyleSheet, Dimensions, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { 
  FadeInDown, 
  FadeInUp, 
  FadeIn,
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  Easing,
} from 'react-native-reanimated';
import { useEffect, useState } from 'react';
import { getFaceResults, getPremiumStatus } from '../../utils/userData';
import SideDrawer from '../../components/SideDrawer';

const { width } = Dimensions.get('window');

interface FaceResults {
  overall: number;
  potential: number;
  masculinity: number;
  skinQuality: number;
  jawline: number;
  cheekbones: number;
  eyeArea?: number;
  harmony?: number;
  summary?: string;
}

const getScoreColor = (score: number) => {
  if (score < 4) return '#ef4444';
  if (score < 6.5) return '#f97316';
  return '#22c55e';
};

// Results View Component (shown when user has results + premium)
function ResultsView({ results }: { results: FaceResults }) {
  const router = useRouter();
  
  const metrics = [
    { label: 'Overall', score: results.overall },
    { label: 'Potential', score: results.potential },
    { label: 'Masculinity', score: results.masculinity },
    { label: 'Skin Quality', score: results.skinQuality },
    { label: 'Jawline', score: results.jawline },
    { label: 'Cheekbones', score: results.cheekbones },
  ];

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.resultsContent}>
      {/* Main Score */}
      <Animated.View entering={FadeInDown.delay(100).springify()} style={styles.mainScoreCard}>
        <LinearGradient colors={['#0f172a', '#0c1929']} style={styles.scoreCardGradient}>
          <View style={styles.scoreCircle}>
            <Text style={styles.scoreValue}>{results.overall.toFixed(1)}</Text>
            <Text style={styles.scoreLabel}>Overall</Text>
          </View>
          <View style={styles.potentialBadge}>
            <Ionicons name="trending-up-outline" size={14} color="#22c55e" />
            <Text style={styles.potentialText}>Potential: {results.potential.toFixed(1)}</Text>
          </View>
        </LinearGradient>
      </Animated.View>

      {/* Metrics Grid */}
      <Animated.View entering={FadeInUp.delay(200).springify()} style={styles.metricsGrid}>
        {metrics.slice(2).map((metric, index) => (
          <LinearGradient key={metric.label} colors={['#0f172a', '#0c1929']} style={styles.metricCard}>
            <Text style={styles.metricLabel}>{metric.label}</Text>
            <Text style={[styles.metricScore, { color: getScoreColor(metric.score) }]}>
              {metric.score.toFixed(1)}
            </Text>
            <View style={styles.metricBar}>
              <View style={[styles.metricFill, { width: `${metric.score * 10}%`, backgroundColor: getScoreColor(metric.score) }]} />
            </View>
          </LinearGradient>
        ))}
      </Animated.View>

      {/* Summary */}
      {results.summary && (
        <Animated.View entering={FadeInUp.delay(300).springify()}>
          <LinearGradient colors={['#0f172a', '#0c1929']} style={styles.summaryCard}>
            <Ionicons name="bulb-outline" size={20} color="#38bdf8" />
            <Text style={styles.summaryText}>{results.summary}</Text>
          </LinearGradient>
        </Animated.View>
      )}

      {/* My Program Banner */}
      <Animated.View entering={FadeInUp.delay(350).springify()}>
        <TouchableOpacity onPress={() => router.push('/peptide-plan')} activeOpacity={0.9}>
          <LinearGradient 
            colors={['#0284c7', '#0ea5e9', '#38bdf8']} 
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.peptideBanner}
          >
            <View style={styles.peptideBannerLeft}>
              <View style={styles.peptideBannerIcon}>
                <Ionicons name="flask-outline" size={28} color="white" />
              </View>
              <View style={styles.peptideBannerText}>
                <Text style={styles.peptideBannerTitle}>Reach Your Full Potential</Text>
                <Text style={styles.peptideBannerSubtitle}>
                  View your personalized program →
                </Text>
              </View>
            </View>
            <View style={styles.peptideBannerSparkle}>
              <Ionicons name="star" size={20} color="#fbbf24" />
            </View>
          </LinearGradient>
        </TouchableOpacity>
      </Animated.View>

      {/* Rescan Button */}
      <Animated.View entering={FadeInUp.delay(400).springify()}>
        <TouchableOpacity onPress={() => router.push('/onboarding/face-scan')}>
          <LinearGradient colors={['rgba(56,189,248,0.2)', 'rgba(14,165,233,0.1)']} style={styles.rescanBtn}>
            <Ionicons name="refresh-outline" size={20} color="#38bdf8" />
            <Text style={styles.rescanText}>Scan Again</Text>
          </LinearGradient>
        </TouchableOpacity>
      </Animated.View>
    </ScrollView>
  );
}

// Animated Logo Component
function AnimatedLogo() {
  const pulseAnim = useSharedValue(1);
  const rotateAnim = useSharedValue(0);

  useEffect(() => {
    pulseAnim.value = withRepeat(
      withSequence(
        withTiming(1.1, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
        withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      true
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseAnim.value }],
  }));

  return (
    <Animated.View style={[styles.animatedLogoWrapper, animatedStyle]}>
      <LinearGradient colors={['#38bdf8', '#0ea5e9', '#0284c7']} style={styles.animatedLogo}>
        <Ionicons name="eye-outline" size={48} color="white" />
      </LinearGradient>
      <View style={styles.logoSparkle1}>
        <Ionicons name="star-outline" size={16} color="#fbbf24" />
      </View>
      <View style={styles.logoSparkle2}>
        <Ionicons name="star" size={12} color="#38bdf8" />
      </View>
    </Animated.View>
  );
}

// Animated Scan Line
function AnimatedScanLine() {
  const translateY = useSharedValue(0);

  useEffect(() => {
    translateY.value = withRepeat(
      withTiming(250, { duration: 2000, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));

  return (
    <Animated.View style={[styles.movingScanLine, animatedStyle]}>
      <LinearGradient 
        colors={['transparent', '#38bdf8', 'transparent']} 
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.scanLineGradient}
      />
    </Animated.View>
  );
}

// Initial Scan View (shown when no results yet)
function InitialScanView() {
  const router = useRouter();
  
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.initialContent} showsVerticalScrollIndicator={false}>
      {/* Animated Hero Logo */}
      <Animated.View entering={FadeIn.delay(100).duration(800)} style={styles.heroContainer}>
        <AnimatedLogo />
        <Animated.Text entering={FadeInDown.delay(300).springify()} style={styles.heroTitle}>
          LooksMax AI
        </Animated.Text>
        <Animated.Text entering={FadeInDown.delay(400).springify()} style={styles.heroSubtitle}>
          Unlock your facial potential with AI
        </Animated.Text>
      </Animated.View>

      {/* Main Scan Card */}
      <Animated.View entering={FadeInUp.delay(500).springify()}>
        <LinearGradient colors={['#0f172a', '#0c1929']} style={styles.scanCard}>
          <View style={styles.faceContainer}>
            <View style={styles.facePlaceholder}>
              <Ionicons name="person-outline" size={100} color="#4a4a6a" />
            </View>
            {/* Static scan lines */}
            <View style={styles.scanOverlay}>
              {[...Array(6)].map((_, i) => (
                <View key={i} style={[styles.scanLine, { top: `${15 + i * 14}%` }]} />
              ))}
            </View>
            {/* Animated scan line */}
            <AnimatedScanLine />
          </View>
          <Text style={styles.cardTitle}>Get your ratings and recommendations</Text>
          <TouchableOpacity onPress={() => router.push('/onboarding/face-scan')} style={styles.scanButtonContainer}>
            <LinearGradient colors={['#38bdf8', '#0ea5e9']} style={styles.scanButton}>
              <Ionicons name="camera-outline" size={20} color="white" style={{ marginRight: 8 }} />
              <Text style={styles.scanButtonText}>Begin Scan</Text>
            </LinearGradient>
          </TouchableOpacity>
        </LinearGradient>
      </Animated.View>

      {/* Feature Cards */}
      <Animated.View entering={FadeInUp.delay(600).springify()} style={styles.featuresRow}>
        <TouchableOpacity style={styles.featureCard} onPress={() => router.push('/onboarding/face-scan')}>
          <LinearGradient colors={['rgba(56,189,248,0.15)', 'rgba(14,165,233,0.05)']} style={styles.featureGradient}>
            <Ionicons name="happy-outline" size={28} color="#38bdf8" />
            <Text style={styles.featureTitle}>Face Scan</Text>
          </LinearGradient>
        </TouchableOpacity>
        <TouchableOpacity style={styles.featureCard} onPress={() => router.push('/body-scan')}>
          <LinearGradient colors={['rgba(56,189,248,0.15)', 'rgba(14,165,233,0.05)']} style={styles.featureGradient}>
            <View style={styles.newBadge}><Text style={styles.newBadgeText}>NEW</Text></View>
            <Ionicons name="fitness-outline" size={28} color="#38bdf8" />
            <Text style={styles.featureTitle}>Body Scan</Text>
          </LinearGradient>
        </TouchableOpacity>
      </Animated.View>

      {/* Stats */}
      <Animated.View entering={FadeInUp.delay(700).springify()} style={styles.statsContainer}>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>1M+</Text>
          <Text style={styles.statLabel}>Users</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>4.9</Text>
          <Text style={styles.statLabel}>Rating</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>99%</Text>
          <Text style={styles.statLabel}>Accuracy</Text>
        </View>
      </Animated.View>
    </ScrollView>
  );
}

export default function ScanTab() {
  const [results, setResults] = useState<FaceResults | null>(null);
  const [isPremium, setIsPremium] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [drawerVisible, setDrawerVisible] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [faceResults, premiumStatus] = await Promise.all([
          getFaceResults(),
          getPremiumStatus(),
        ]);
        setResults(faceResults);
        setIsPremium(premiumStatus.isPremium);
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  const showResults = results && isPremium;

  return (
    <LinearGradient colors={['#071018', '#0c1929', '#071018']} style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setDrawerVisible(true)} style={styles.menuBtn}>
          <Ionicons name="menu-outline" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{showResults ? 'Your Results' : 'LooksMax AI'}</Text>
        <TouchableOpacity style={styles.menuBtn}>
          <Ionicons name="notifications-outline" size={24} color="#6b7280" />
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      ) : showResults ? (
        <ResultsView results={results} />
      ) : (
        <InitialScanView />
      )}

      {/* Side Drawer */}
      <SideDrawer visible={drawerVisible} onClose={() => setDrawerVisible(false)} />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 60, paddingBottom: 16 },
  headerTitle: { fontSize: 22, fontWeight: 'bold', color: 'white' },
  menuBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.08)', alignItems: 'center', justifyContent: 'center' },
  content: { flex: 1, paddingHorizontal: 24, justifyContent: 'center' },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { color: '#9ca3af', fontSize: 16 },
  // Animated Logo styles
  animatedLogoWrapper: { position: 'relative', marginBottom: 16 },
  animatedLogo: { width: 90, height: 90, borderRadius: 45, alignItems: 'center', justifyContent: 'center', shadowColor: '#38bdf8', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.5, shadowRadius: 20 },
  logoSparkle1: { position: 'absolute', top: -6, right: -6, width: 28, height: 28, borderRadius: 14, backgroundColor: '#0f172a', alignItems: 'center', justifyContent: 'center' },
  logoSparkle2: { position: 'absolute', bottom: 0, left: -8, width: 24, height: 24, borderRadius: 12, backgroundColor: '#0f172a', alignItems: 'center', justifyContent: 'center' },
  movingScanLine: { position: 'absolute', left: '5%', right: '5%', height: 2 },
  scanLineGradient: { height: 2, width: '100%' },
  // Initial content styles
  initialContent: { paddingHorizontal: 24, paddingBottom: 40 },
  heroContainer: { alignItems: 'center', marginBottom: 28, marginTop: 10 },
  heroTitle: { fontSize: 32, fontWeight: 'bold', color: 'white', marginBottom: 8 },
  heroSubtitle: { fontSize: 15, color: '#9ca3af', textAlign: 'center' },
  // Feature cards
  featuresRow: { flexDirection: 'row', gap: 12, marginTop: 20, marginBottom: 20 },
  featureCard: { flex: 1 },
  featureGradient: { borderRadius: 16, padding: 20, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)' },
  featureTitle: { color: 'white', fontWeight: '600', fontSize: 14, marginTop: 10 },
  // Stats
  statsContainer: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: 16, padding: 16, alignItems: 'center', justifyContent: 'center' },
  statBox: { flex: 1, alignItems: 'center' },
  statNumber: { fontSize: 24, fontWeight: 'bold', color: 'white' },
  statLabel: { fontSize: 12, color: '#6b7280', marginTop: 2 },
  statDivider: { width: 1, height: 32, backgroundColor: 'rgba(255,255,255,0.1)' },
  // Initial Scan View styles
  scanCard: { borderRadius: 24, padding: 24, alignItems: 'center' },
  faceContainer: { width: width - 96, height: 240, borderRadius: 16, backgroundColor: '#252540', marginBottom: 20, overflow: 'hidden', position: 'relative' },
  facePlaceholder: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  scanOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  scanLine: { position: 'absolute', left: '10%', right: '10%', height: 1, backgroundColor: 'rgba(56,189,248,0.3)' },
  newBadge: { position: 'absolute', top: 8, right: 8, backgroundColor: '#ef4444', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  newBadgeText: { fontSize: 9, fontWeight: 'bold', color: 'white' },
  cardTitle: { fontSize: 20, fontWeight: 'bold', color: 'white', textAlign: 'center', marginBottom: 20 },
  scanButtonContainer: { width: '100%' },
  scanButton: { borderRadius: 30, paddingVertical: 16, alignItems: 'center', flexDirection: 'row', justifyContent: 'center' },
  scanButtonText: { color: 'white', fontWeight: 'bold', fontSize: 17 },
  pagination: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginTop: 24 },
  dotActive: { width: 8, height: 8, borderRadius: 4, backgroundColor: 'white' },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#4a4a6a' },
  // Results View styles
  resultsContent: { paddingHorizontal: 24, paddingBottom: 32 },
  mainScoreCard: { marginBottom: 20 },
  scoreCardGradient: { borderRadius: 24, padding: 32, alignItems: 'center' },
  scoreCircle: { width: 140, height: 140, borderRadius: 70, borderWidth: 4, borderColor: '#38bdf8', alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(56,189,248,0.1)', marginBottom: 16 },
  scoreValue: { fontSize: 48, fontWeight: 'bold', color: 'white' },
  scoreLabel: { fontSize: 14, color: '#9ca3af', marginTop: 4 },
  potentialBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(34,197,94,0.15)', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, gap: 6 },
  potentialText: { color: '#22c55e', fontWeight: '600', fontSize: 14 },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  metricCard: { width: (width - 60) / 2, borderRadius: 16, padding: 16 },
  metricLabel: { color: '#9ca3af', fontSize: 12, marginBottom: 4 },
  metricScore: { fontSize: 28, fontWeight: 'bold', marginBottom: 8 },
  metricBar: { height: 6, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 3, overflow: 'hidden' },
  metricFill: { height: '100%', borderRadius: 3 },
  summaryCard: { borderRadius: 16, padding: 16, flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 20 },
  summaryText: { flex: 1, color: '#d1d5db', fontSize: 14, lineHeight: 20 },
  rescanBtn: { borderRadius: 16, paddingVertical: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1, borderColor: 'rgba(56,189,248,0.3)' },
  rescanText: { color: '#38bdf8', fontWeight: '600', fontSize: 16 },
  // Peptide Banner
  peptideBanner: { borderRadius: 20, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, shadowColor: '#38bdf8', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 12 },
  peptideBannerLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  peptideBannerIcon: { width: 52, height: 52, borderRadius: 26, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  peptideBannerText: { marginLeft: 12, flex: 1 },
  peptideBannerTitle: { fontSize: 16, fontWeight: 'bold', color: 'white' },
  peptideBannerSubtitle: { fontSize: 12, color: 'rgba(255,255,255,0.8)', marginTop: 2 },
  peptideBannerSparkle: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(0,0,0,0.2)', alignItems: 'center', justifyContent: 'center' },
});
